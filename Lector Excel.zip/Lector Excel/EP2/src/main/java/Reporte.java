
import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;


public class Reporte {
    private final String Ruta;
    private final ArrayList<Usuario>LUsuarios=new ArrayList<Usuario>();
    
    
    
    public Reporte(String Ruta){
        this.Ruta=Ruta;
        
    }
    
    public void Leer() throws CsvValidationException{
        File file = new File(this.Ruta);
        try {
            FileReader inputfile = new FileReader(file);
            CSVReader reader = new CSVReader(inputfile);
        
            String[] nextRecord;
            
            // we are going to read data line by line
            int i=0;
            while ((nextRecord = reader.readNext()) != null) {
                
                //System.out.println(nextRecord[4]);
                if(i>0)LUsuarios.add(new Usuario(nextRecord[0],nextRecord[1],nextRecord[2],nextRecord[3]));
                  
                
                for (String cell : nextRecord) {
                    
                    System.out.print(cell + "\t");
                }
                i++;
                System.out.println();
            }
            
        
        }catch (IOException e) {
            // TODO Auto-generated catch block

        }
    }
    
    public void Escribir(String [] header, ArrayList <Usuario> Datos){
        File file = new File(this.Ruta);
        try {
        // create FileWriter object with file as parameter
        FileWriter outputfile = new FileWriter(file);
  
            // adding header to csv
            //String[] header = { "Name", "Class", "Marks" };
            try ( // create CSVWriter object filewriter object as parameter
                    CSVWriter writer = new CSVWriter(outputfile)) {
                // adding header to csv
                //String[] header = { "Name", "Class", "Marks" };
                writer.writeNext(header);
                // add data to csv
                for (int i = 0; i<Datos.size(); i++) {
                    String[] data = {Datos.get(i).getRegion(),Datos.get(i).getComuna(),Datos.get(i).getnUsuarios(),Datos.get(i).getProvincia(),};
                    writer.writeNext(data);
                }
                // closing writer connection
            }
    }
    catch (IOException e) {
            // TODO Auto-generated catch block

    }
        
    }
}
