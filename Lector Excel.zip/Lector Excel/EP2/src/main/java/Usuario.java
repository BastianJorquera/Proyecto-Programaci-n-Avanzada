public class Usuario {
    private String Comuna;
    private String Provincia; 
    private String Region;
    private String nUsuarios;

    public Usuario(String Comuna, String Provincia, String Region, String nUsuarios) {
        this.Comuna = Comuna;
        this.Provincia = Provincia;
        this.Region = Region;
        this.nUsuarios = nUsuarios;
    }

    public String getComuna() {
        return Comuna;
    }

    public String getProvincia() {
        return Provincia;
    }

    public String getRegion() {
        return Region;
    }

    public String getnUsuarios() {
        return nUsuarios;
    }
    
    

    public void setUsuario(String Comuna) {
        this.Comuna = Comuna;
    }

    public void setProvincia(String Provincia) {
        this.Provincia = Provincia;
    }

    public void setRegion(String Region) {
        this.Region = Region;
    }

    public void setnUsuarios(String nUsuarios) {
        this.nUsuarios = nUsuarios;
    }
    
    
}
