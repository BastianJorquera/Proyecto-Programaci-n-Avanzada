
import com.opencsv.exceptions.CsvValidationException;

public class Principal {

    public static Reporte reporte;
    public static void main(String args[]) throws CsvValidationException {
        reporte=new Reporte("src/test/usuarios.csv");
        
        reporte.Leer();
        
    }
}
